﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ScottPlot;

namespace barchart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random rand = new(0);
            List<ScottPlot.Plottable.Bar> bars = new();
            for(int i=0;i<10;i++)
            {
                int value = rand.Next(25, 100);
                ScottPlot.Plottable.Bar bar = new()
                {
                    Value = value,
                    Position = i,
                    FillColor = Palette.Category10.GetColor(i),
                    Label = value.ToString(),
                };
                bars.Add(bar);
            }
            formsPlot1.Plot.Style(Style.Seaborn);
            formsPlot1.Plot.AddBarSeries(bars);
            formsPlot1.Plot.SetAxisLimitsY(0, 120);
            formsPlot1.Refresh();
            
        }
    }
}
